package com.reactive;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class App06SpringReactivePluralSightApplication {

	public static void main(String[] args) {
		SpringApplication.run(App06SpringReactivePluralSightApplication.class, args);
	}

}
