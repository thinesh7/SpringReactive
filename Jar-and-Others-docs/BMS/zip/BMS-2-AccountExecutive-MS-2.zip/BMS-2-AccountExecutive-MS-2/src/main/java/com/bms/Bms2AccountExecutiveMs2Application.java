package com.bms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bms2AccountExecutiveMs2Application {

	public static void main(String[] args) {
		SpringApplication.run(Bms2AccountExecutiveMs2Application.class, args);
	}

}
