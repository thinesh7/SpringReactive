package com.bms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Bms2AccountExecutiveMs2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
