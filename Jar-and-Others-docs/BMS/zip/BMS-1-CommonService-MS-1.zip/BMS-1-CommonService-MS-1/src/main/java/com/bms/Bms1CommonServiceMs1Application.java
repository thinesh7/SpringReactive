package com.bms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bms1CommonServiceMs1Application {

	public static void main(String[] args) {
		SpringApplication.run(Bms1CommonServiceMs1Application.class, args);
	}

}
