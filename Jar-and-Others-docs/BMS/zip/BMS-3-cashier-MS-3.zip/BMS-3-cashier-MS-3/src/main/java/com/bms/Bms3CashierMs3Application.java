package com.bms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bms3CashierMs3Application {

	public static void main(String[] args) {
		SpringApplication.run(Bms3CashierMs3Application.class, args);
	}

}
